var HaloConsoleShared=function(n){"use strict";function e(i){return i}return n.definePlugin=e,n}({});
//# sourceMappingURL=halo-console-shared.iife.js.map
